<script setup lang="ts">
import AdminLayout from '@/layouts/admin/AdminLayout.vue'
import { router, Head } from '@inertiajs/vue3'
import { ref } from 'vue'
type Role = {
    id: number
    name: string
    guard_name?: string
}

const props = defineProps<{
    users: Array<{
        id: number,
        nama: string,
        email: string,
        roles: Role[],
    }>,
    roles: Role[],
    filters: {
        search?: string
    }
}>()
const search = ref(props.filters.search || '')

function submitSearch() {
    router.get('/superadmin/users', { search: search.value }, {
        preserveScroll: true,
        preserveState: true,
    })
}

function toggleRole(user: number, roleName: string) {
    router.post(`/superadmin/users/${user}/sync-roles`, { roles: [roleName] }, {
        preserveScroll: true,
        onSuccess: () => {
            const users = props.users.find(u => u.id === user)
            if (users) {
                users.roles = props.roles.filter(role => role.name === roleName)
            }
        }
    })
}

</script>

<template>

    <Head title="Manajemen Pengguna" />
    <AdminLayout>
        <div>
            <div class="mb-4 flex gap-4">
                <a href="/pegawai/dashboard" class="font-bold text-customGreen hover:text-green-700 hover:underline transition">
                    Daftar User & Pegawai
                </a>
                <a href="/superadmin/users" class="font-bold text-customGreen hover:text-green-700 hover:underline transition">
                    Ke Manajemen Pengguna
                </a>
            </div>
            <div class="flex items-center gap-2 mb-2">
                <svg width="35" height="35" viewBox="0 0 35 35" fill="none" xmlns="http://www.w3.org/2000/svg"
                    xmlns:xlink="http://www.w3.org/1999/xlink">
                    <rect width="35" height="35" fill="url(#pattern0_1674_7472)" />
                    <defs>
                        <pattern id="pattern0_1674_7472" patternContentUnits="objectBoundingBox" width="1" height="1">
                            <use xlink:href="#image0_1674_7472" transform="scale(0.01)" />
                        </pattern>
                        <image id="image0_1674_7472" width="100" height="100" preserveAspectRatio="none"
                            xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAYAAABw4pVUAAAACXBIWXMAAAsTAAALEwEAmpwYAAASWElEQVR4nO2dCXATV5rHO7uZ2a2Z2SM1m9qa2Zmtmt2dqtmdyU7NSgkhITGJZAhgtQDHQLgMmDEzhMMXlrplW76xJZ9Yki1L8iEfYBtijCUZzOGT0xACBAwYmxDCYUggQMyNv63XVrdal/EtteBf9ZWR1HpSf79+7/ve914LDHupl3opL5Zc/Md/JsT/9x6J85ZKxfwoUsyTkGJ+GCHiL5bhb74v9/P7e09/R58XEcD7HSnmJ5E47xSB85+RYj64NZx3n8T5ZhnOF3r6e/ucJDj/TwTOs5Bifv+gEMTu4PB3bcD/9EtPnwfnhYYdAudl2/eGNyFp3mTIDv4AtKumgeHTmVC6dhZUhImgfL2I+jd6PmvpVIib+xa7x1yOmTXpt54+J86KEE36V0LM66AdGjP7TchY8j7l8MpwfEhWHiaiwCGIqA1CzDsb6f+/P/X0uXEzYOP8MzSMlAXvDgtEpYOpVwrZPaWKnM0PJfE3+RiGveLpc/V6hYbyfkTivD20A9HQUxE2MhCVLEue/46rwN9NiHkLX4IZRCTOT6cdlrnEb9QgKq2mCmH1EgcjxLxyedD//HjiLjuOSCZ66zekmP+QHqbGomdUOlhFOA6la2ZB3vIPIdYu6PMrPH3+XifkFOQc2Ww+FK+ZOeYwKh3MuC4AkoLeZqBIRbxgT/vAaySd9cZrJM5/jByjXDx2Q1XlcwwlC7FzBnoKIeb1yP38XvW0L7xCqORBX6n61R9NGJDKcBzyVnxoG7pEPLGnfeEVIsW8zcghsXMnQWW4aEKBlIcFgGwOHeR5Kk/7witE4vyjyCFpC6eMucMNq2dAQtBkyAsRQIUb2ClMWsz73NO+8AqRYv4V5JCMMUx1K6yTQjTLp4ek5HnvgHGd8yQTfa71mCue9oVXiA7o2cs+GAMYIqqehWperuYd8o8nQYlDFpe9fCokfPI2JAdPfqKWCqM0pFCiIYVhasJ/sUrm/36x/AUr55Ni/g/UZDB46ogAlKydBQWh06jJpDxwkh2AzJAPoHN7ONSmzrdBCXwLStbPhKLoGaCV+oOGFICGFA5m99WkwKyRCV6Mcj6B83sHhqz33c4Z1CsF1OsbP3kXUua/C0nz3oH4wEmsgGxvyQvfhRZtCNw9mgR9n6dQtnvTUoifPwmy1k19HoBBTLArb4PQt8v5dDExfdF7TvMExaL3QDbEtY/4eW9DqUQEHWWr4c6RRAYEMgSmuWiZnXPzZUKoUsyBVmMInDdHwDf7CLi5Pw7uHU2GO4cToLc9Fs6Zw6G5ZDkUJcxkv/dyfozQd8v5pJjfSJdMaBgoDsRYJ220JcyfDLmrBFAYNgOMUhy2yOfCDsUncLBoFXTVR9n1BrZ9d0AOVco5jEMLYvxhryEYbrTHujzeld3tSIL2spWQb21DTQjPKiP9fbOcT+J8PXJ4HDUPQTCmg8yaHaG/lTFzKIf/cCx5yA7ss9rtwwlQsRFnYHyW/fGwQDjaic/WMG2pSUGVhhSEFpBCPvhSOV+G8yLoXlC8ZgZTzogPehtOVq8bsfPuHU2C2pwgxoH7DMHUcyNtj7Zt2R+7ii/dGkK40CfAECKePw2Ena4e37xmVI5rLQ1hHLZbt3TUIGjr2bXBbdBXE8LyankQt8v55HTeLxwDdFFUwKicdr0tFrSx0ygn1WTMpWLAWAFxjE+n6tZDZZqYNZQJuV3OVxOC+JhA+wDeUb56VI5qKFjEOOjSHsm4wHAcHndqF9t6i1TA3XK+mhBcTVxkW5tAdrVJNmLn3D6UAAUxA71jR96CcYdBG0o6tmUGDgAhBD1yOUfL+WpC+CDtz1PsgDjOI4Zjp7avY67U0zvWTxgQZGguQ3+2ihRws5yPcvqc9VPtgIxquMpfxEz8bh2Kn1AgyLZmDfQSNSngZjlfQwo3qQkBtXw7FkCqrJPAspTRJQau7LuD8VTa21S0jBoaXR2zv3wlHdy5Wc7XEP5/0BCCZwkLbXEElS9G6rSSpFmUQ7Yo54wpDJTuGpMDmCGpOHEmXNwd7XTcl3X0kCngbjlfTQh0mev8YGPIFMpQTWmkjiuwBnQUYMcCxMXGaKjbNN/lvKMwdhpV72If32WJtM5JBI8wrgrVhVSE4Dx9oq6uvKGaLm461QYqHI7k/ehiQMVGVFQsZ5VdkFUqAuHqgQxoq1jLqo1Ng66GSOb96L102R7jsnI2CH9Ln+ShitARAylKmEG1UZ4qcvn6nY5EOFMfBi3Fy8GkWgCf5QRRcQcdXxj3kcueUJwYAKdMMfDsQilATxlln9dGM6/r5B9Rk1HUPpooWoesGxjXpSGF5+jZ9UiBVFiv6qLEmQ4gkqiAS/eg55lePgMaCldA155EeNplA8E2dk9BhUv0OZ9v/ZQO6qcxrktDCtPpE/xqhDPs2tx5A0OJzJ9JDq61xkAFq7yBzBA/E6oz58EO1RLYWbgC9pWsggNbwqBzZzz0Hs626w3uDIGqyrAVMDtN4bYsixDsxLgutWzarzWE8Ak6IeTYvhGU3HfrljIOutoio8rtdOalkfnDnqJQ6D2cBf3dgzt7qPZ1azrzeTWZgdBYuMQ6WxdqMV+QmhSW0Cd4fOunwwZypOovdlfsVms5A43zl1o2jgkER6vJsmVhZSkiuoesxXxBWrnfv6hJ4fWBtHI6lf8PB8iFhoG0k860mMytKXVcYCA7xgrwrFK8H+Yr0kiFOJosUld23HS4sDNqyEC+3R/n5BxTfvC4wUB2/VC202eWSgU/x3xJ+cSHq9TMhgR/Kli6WzfvYxkdVNl2YU/SuAL54ZTWRQ8RxGO+JhUhNNlddckBcKxmNVVTcgekONFuhwhl904WjCuQ/gtGV0CuYr4mdJW5miOgHoOKfF85pMZoTYIunbDN3TxiLM1FDHmA+TKQpqJgMMQPzMJpK0maBWdN4fD9kURqZXAXe9WOZeMNwyUQUtCJ+TKQnl1R0N0QCUc2rwJT3nyXPUFj7T3eAAQtK2C+DoRtHVWrmLoVbehxa+lyZkMbbU/Ol0xsDEEZIuH/B8xX5CdvelUcY34jmVhW7Q4Isi5LBBwoXwl7dEuov+gxen5H3kD5hLa7J/PHFcj904WOAV2HcV1Bkt3/JCbNK3HCZBERpns4aYYIMgYGA9Ljxs5bIsAgt/Wey+2KcQVysyOX1TuEx7TygJ9gXNWcaMuvRIQ5FyfMfQgC29hAUPwYDpR9hmDmvYdrIsYVyCmzzForE/apVvv9DOOiguTVPxYRZtIRxNy4XRCSfRiiis9Dan4l49TduiXDAnKy1rYPF1VkxxNIg3Y5nVkZMS5qtszynyLC1MEGsXhjKxAVPaCw3AZlw/eUZZhvgCppoHqKAnVz8TLo2Tk0IF3mCGqJlYbyzTgNWyg+Fcisn0N8uADjmgJklik4ab5Fg1iQ3ARk5VcMBEfLrDkBmtiBCiqyyjQc2o0hcNYU5hIE2mSwV7/UKQOr3bRozErubGstG+iJ+aT/FW0o70cYlxRAWAQi0nyfhvHn3A5IM91yC4MNRZXoPOkrSpgBFak4bE4XQ1lqAFVid54P2OYlp0yyMYVx/WAW5McMtK8iBOEYlzRbauKJSPNdBEIsM0NE0dnngrAzUy/kFJaAOt7l7QDgNFOO/5g6Pkdvi0NoA/ZYZVwo1S3faC3vy4THOdU7ZklNr4lI00W6Z6zXnRkeDDu7DVk1xyBHVwK5qgzYlBULeYoI6i96jCCg19Fx1PGW25CntK2R6OJmUKt8o4HxsFNPLf9a23yYFyN8A+OScMJcTcNYqz05Chgjs4z6K6BKsd0vgraZHq6JhKddw5/Bf9uxCcrTmIWvZ2rSX4RxSQFSyzR2JsXOoiYUSt1FUMutu9OtZkwRU3Hl/hn9c0E8OmuAg1VhzH0nlEmFNY7nK1MW/gbzXsErOGk6gWDMjmmAhG1XPQJDabWc/HzXBckYf9ietxiuH8pyqlFd2a+EfSV/BX38zCEtQkmUunipQqfAvFG4tB6ne8df1cc9CkOJgBTYak7sjQm0labg1Nr7o3NF1M6UvcWr7F7XyWfAka2Rzwei1INEocuXy+V/g3mTRKTJPJBVWSCp9rpXAYFuIxXcm42rqZ2J7rI1qvdsWgQn60l40Kmjes5QgFitLKi6+m8xb9BHhOV1nDA9QUBWZB3yOAylIxDW0ISCu6XA/ocF6N2Ll1rSnOLJMICAVKHbHKrVej4lxon6BfRwFW3s8iwMy21IreuFjLy8QReteppSqI105vxl1NCENi+4Oo5uI1MeUh2ed+ANubzpVbdAKCj6HWtzc//Ow0DMahpIyvYbEw5BYb4FCdUXQVZ8AqILDkCUph1S0pLHZBWRbgO1h9qN0rTfi1S3mSPVbSESpX4jDUJVtp3dU0xyebHnflkIJ03NCMa8xL0TCiK9/luIK++EqPz9tLMYYwMZyt5dV4be5wIIYxtyah/TEB49fgyFVWYGikSpa96Qrv8HjwARkabLjusb42limQWWpe2BCHWbnYMI3SHIqjsL5Yd7oXJHLePMo59tGD6QbiNTTKQKnTtqqXZR++hz0OdF59p6BdLjx0/AUN3A7ilt8tyyf5x4INZVv4mwwLgGWJPTYgcidcsJqPniFrRc64fW60BZy5VHoFcEM7N1qtjYbRwSjCfni2FviW3fsEG5jGqPaftaP/V58kKLHRCkJ0+fgrF2NzumHJWmlk7szkacMKXihDltvG1RcmN5hKrtAQ0i3ngMtp28zTjK0RpPdYM23nZn1LacT+BcYwI8cDNbv3MiH45vl1KzeqZIGY9D45fdLts3NB5zAoL09OkzKK/bYxu+FLrTZJb2F5gvKULVKojStN2nYeSaz0PTN0/dwmBD0acvdTkxRBPG2tyFUJUZBEUJzvMT9D70fndtuwOC9Ky/H6otzSwo+k4ys+TfMF9QpKaNF6luu0sFUk07GA9cey4ItjVffgDbzFtAm2y74WYwQ8eh49H7Bmt3MCA0lK07W1lpse6iNMvwHxiXJdW0vRapbrtI94zitm+GBYNtaOzfdfIc5ewtWzZBRVEiGPOjqb/oMXoevc6ORaMBgtQPAPV7D7LnKpekmbr/wriqSE17NQ1D1/T1iGGMhw0FCK3GtqPsnnKNUOq5t7kuSt0+jZ1JtQzxyvVGIEjNh0+ws69eSabhjxhnBPBKpKb9BJXvFxwAc1efxwGMFghSCwuKRKG7LVUaJmFcUISmHad7R/7uHo87f6yAIB08fgaIDAOdfd0j0vUfYN4uVC+isqr8/bCze/Bsh2tAkI6cOGuDotT3SRUG7/3xZiK39fVITfsTBCSrrtPjjm8dByBIX3ReADKziI4pDyWKQu/83a1Izf4F9HC1+ehNnwWCdObCJYjJKqYLko8kCn0g5m2K0rSraSCNF201pFYfBIJ0tvtriMkegCJV6J5KFIalmDcpUtPejGDElR71uNNbJwAIUvfXVyEup9QGJV2/AvMWRWraLjuuPUR5oTmW30eri5evgTyXgdIvydCvx7xBaFXuRQSCdPnaTUhUlbEWuvQx3gAkNUrTnubtFp1d1T4aIPf67sOlq71UttV06AvYtqsN9NUWOyDW3hLraSackIS1yWE4QsXG2JwSe6c/zxS6FE+fr88COddz2Z3jb1ErjEp9tVShS0MxRKrQB0kzdLxIpdE3/8uMiQTyw/0HcOiLTpcl+Qx9NT0h/A5VfuVyLXdvHuUCkGs3voP0wi0Qm10MfQ8eOr3efuxLpmdEZxRO9/S5+DSQ011f2eYUSj20HDnpBOTBw0fMMRKlvt7T5+KTQPoBYO/B40A4xAbUU9ByrqO2795PA3nG+aVdbwOC9mRV7tjLBvG9RKEz0o9RzcpRvd/eZuBJlLpMT5+PTwHZVFrLXqI9H52m+2+5SvUzBAY9h+YXrqSrYvZ23XoZ2Ecp15utdS1EiuF11jHZ9GvXb95yAoLiDfPeDF3oaL/TCy2J0+0Ieq3j7QhohwkVI5R6qNtzwAkIii3phVV0G1+ipWvPnRHHJaHvoFLqn0gUhZ+6O06q0FnQcSirQtnVYOvsRLrBd37hdKI1cI+hvleSYZgy2HHSdN1M2uH7j512AnLt5i12/Nk6cWfgY5Io9IGSNO2/P+84dP+hRKHvQg7PNNRQ6TESKixurm8CGb2Ma+1tsoyiX0/MGbzAkioMYbTTLS1HQF1e51TLkij17dFKwzy5XM7N/2SMS0I370gUujvOEHSPBoqJ+sme/o4vnKRKvYa9cxFVdKPTCn/l6e/1wio6rfD3qLyONjGM5MbQ/wdvHJVx82N6twAAAABJRU5ErkJggg==" />
                    </defs>
                </svg>
                <h1 class="text-2xl font-bold text-customGreen mb-6 pt-6">Manajemen Pengguna</h1>
            </div>

            <div class="mb-4 flex items-center gap-2">
                <input v-model="search" @keyup.enter="submitSearch" type="text" placeholder="Cari nama atau email..."
                    class="border rounded px-3 py-1" />
                <button @click="submitSearch" class="bg-blue-600 text-white px-3 py-1 rounded">Cari</button>
            </div>

            <table class="table-auto w-full border-separate rounded-lg overflow-hidden" style="border-spacing:0;">
                <thead>
                    <tr class="bg-customDarkGreen text-white text-left">
                        <th class="p-2 border-b rounded-tl-lg">Nama</th>
                        <th class="p-2 border-b">Email</th>
                        <th class="p-2 border-b rounded-tr-lg">Roles</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(user, index) in users" :key="user.id"
                        :class="index % 2 === 0 ? 'bg-white' : 'bg-gray-200'">
                        <td class="p-2 border">{{ user.nama }}</td>
                        <td class="p-2 border">{{ user.email }}</td>
                        <td class="p-2 border">
                            <div class="flex gap-4">
                                <label v-for="role in roles" :key="role.id" class="flex items-center gap-1">
                                    <input type="radio" :name="'role-' + user.id" :value="role.name"
                                        :checked="user.roles.some(r => r.name === role.name)"
                                        @change="() => toggleRole(user.id, role.name)" />
                                    {{ role.name }}
                                </label>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </AdminLayout>
</template>
