<script setup lang="ts">
import AppLogoIcon from '@/components/AppLogoIcon.vue';
</script>

<template>
    <div class="flex aspect-square size-16 items-center justify-center rounded-md  text-sidebar-primary-foreground">
        <AppLogoIcon class="size-5 fill-current text-white" />
    </div>
    <div class="ml-1 grid flex-1 text-left">
        <span class="text-2xl mb-1.5 font-bold leading-none text-customGreen">SiLanYar</span>
        <span class="text-sm leading-none text-black">Sistem Informasi Laboratorium
            Karanganyar</span>
    </div>
</template>
